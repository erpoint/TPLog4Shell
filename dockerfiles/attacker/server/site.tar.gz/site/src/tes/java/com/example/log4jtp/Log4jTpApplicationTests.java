package com.example.log4jtp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Log4jTpApplicationTests {

    @Test
    void contextLoads() {
    }

}
